# -*- coding: utf-8 -*-
# @Time : 2022/6/21 15:37
# @Author : renyumeng
# @Email : 2035328756@qq.com
# @File : Solve.py
# @Project : ProbabilityTheoryAndMathematicalStatisticsExperiments
